<?php $__env->startComponent('mail::message'); ?>
<h3>Hello <?php echo e($name); ?>,</h3><br>  
Your company has been succesfully registered for CompaList services.
<br>
Best regards,
Augustinas<?php /**PATH C:\xampp\htdocs\itoma-task\resources\views/mails/registration.blade.php ENDPATH**/ ?>