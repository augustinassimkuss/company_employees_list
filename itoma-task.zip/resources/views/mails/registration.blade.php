@component('mail::message')
<h3>Hello {{$name}},</h3><br>  
Your company has been succesfully registered for CompaList services.
<br>
Best regards,
Augustinas